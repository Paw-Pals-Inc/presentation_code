<?php include 'common/login-header.php'; ?>

<!-- Start -->
<div class="box-container">
    <div class="left-box">
        <div class="login">
            <div>  
                <P>
                    <h1>Create Your Account</h1>
                </p>
            </div>
        </div>
        <div class="right-box">
            <form  class="outer-form-account-creation">
                <div class="form-custom">
                    <h2>Description</h2>
                </div>
                <div style="padding:10px">
                    <textarea name="paragraph_text" cols="50" rows="5" placeholder="Your description"></textarea>
                    <textarea name="paragraph_text" cols="50" rows="5" placeholder="Pet Description"></textarea>
                </div>
                <table style="margin-left:auto;margin-right:auto">
                    <tr>
                        <td style="padding:10px"><a href="add_dog_info.php" type="button" class="btn btn-primary">Back</button></td>
                        <td><a href="add_pictures.php" type="button" class="btn btn-primary">Next</button></td>
                    </tr>
                </table>
            </form> 
        </div>
    </div>




