<?php include 'common/login-header.php'; ?>

<!-- Start -->
<div class="box-container">
    <div class="left-box">
        <div class="login">
            <div>  
                <P>
                    <h1>Create Your Account</h1>
                </p>
            </div>
        </div>
        <div class="right-box">
            <form  class="outer-form-account-creation">
                <div class="form-custom">
                    <h2>Select All That Apply:
                    </h2>
                </div>
            <table style="margin-left:auto;margin-right:auto">
                <tr>
                    <td >
                    
                        <input  type="checkbox" class="btn-outline-primary btn-check" id="btn-check-1" checked autocomplete="off">
                        <label class="btn btn-light" for="btn-check-1">Shy</label>

                        <input type="checkbox" class="btn-outline-primary btn-check" id="btn-check-2" checked autocomplete="off">
                        <label class="btn btn-light" for="btn-check-2">Plays Aggressive</label>

                        

                        
                    </td>
                </tr>
                <tr>
                    <td>
                        <input type="checkbox" class="btn-outline-primary btn-check" id="btn-check-3" checked autocomplete="off">
                        <label class="btn btn-light" for="btn-check-3">Likes to run</label>

                        <input type="checkbox" class="btn-outline-primary btn-check" id="btn-check-4" checked autocomplete="off">
                        <label class="btn btn-light" for="btn-check-4">Takes a while to warm up to people</label>
                    </td>
                </tr>
                <tr>
                    <td>
                        <input type="checkbox" class="btn-outline-primary btn-check" id="btn-check-5" checked autocomplete="off">
                        <label class="btn btn-light" for="btn-check-5">Dog Experienced</label>

                        <input type="checkbox" class="btn-outline-primary btn-check" id="btn-check-6" checked autocomplete="off">
                        <label class="btn btn-light" for="btn-check-6">Toy Agressive</label>

                        <input type="checkbox" class="btn-outline-primary btn-check" id="btn-check-7" checked autocomplete="off">
                        <label class="btn btn-light" for="btn-check-7">Comfortable with Strangers</label>
                    </td>
                </tr>
            </table>
            <table style="margin-left:auto;margin-right:auto">
                <tr>
                    <td style="padding:10px">
                        <a href="add_pictures.php" type="button" class="btn btn-primary">Back</button>
                    </td>
                    <td>
                        <a href="home.php" atl="home"><button type="button" class="btn btn-primary">Next</button><a>
                    </td>
                </tr>
            </table>
        </form>
        </div>
    </div>
</div>




