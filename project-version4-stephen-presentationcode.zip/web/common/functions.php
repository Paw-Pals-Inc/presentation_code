<?php

function authenticate_user($name, $password) {
    global $accounts;
    foreach($accounts as $account) {
        if( $name == $account["name"] && $password == $account["password"]){
            return true;
        }
    }
}

function redirect($url) {
    header("Location: $url");
}

function ensure_user_is_authenticated() {
    if (!is_user_authenticated()) {
        redirect('login.php');
    }
}

function is_user_authenticated() {
    return isset($_SESSION['name']);
}

//loads account data from accounts.txt into $accounts($name, $password, $highscore)
function load_account_data() {
    $file = "common/accounts.txt";
    $lines = file($file, FILE_IGNORE_NEW_LINES);
    $accounts =[];

    for ($i = 0; $i < count($lines); $i++) {
            list($name, $password, $highscore) = explode(",", $lines[$i]);
            $accounts[$i] = array("name" => $name, "password" => $password);
    }
    return $accounts;
}

?>