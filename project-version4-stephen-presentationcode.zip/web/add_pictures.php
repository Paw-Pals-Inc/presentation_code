<?php include 'common/login-header.php'; ?>

<!-- Start -->
<div class="box-container">
    <div class="left-box">
        <div class="login">
            <div>  
                <P>
                    <h1>Create Your Account</h1>
                </p>
            </div>
        </div>
        <div class="right-box">
            <form  class="outer-form-account-creation">
                <div class="form-custom">
                    <h2>Upload profile picture</h2>
                </div>
            <table style="margin-left:auto;margin-right:auto">
                <tr>
                        <td style="padding:30px" >
                            <button type="button" class="btn btn-square-md">your profile pic</button>
                        </td>
                        <td>
                            <button type="button" class="btn btn-square-md">pet profile pic</button>
                        </td>
                </tr>
            </table>
            <table style="margin-left:auto;margin-right:auto">
                <tr>
                <td style="padding:10px"><a href="add_descriptions.php"type="button" class="btn btn-primary">Back</button></td>
                <td><a href="add_dog_traits.php" type="button" class="btn btn-primary">Next</button></td>
                </tr>
            </table>
        </form>
    </div>
</div>




